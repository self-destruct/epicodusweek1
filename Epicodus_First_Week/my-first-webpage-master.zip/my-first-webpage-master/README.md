# _{First Webpage Nonsense}_

#### _{A guide to the ministry of silly walks}, {dates have no meaning here}_

#### By _**{scd & cg}**_

## Description

_{This is a detailed description of this application. Its purpose and usage are detailed here.  There is no spoon. }_

## Setup/Installation Requirements

* _nihlist cat_
* _setup instructions_
* _delete meaning_
* _give up hope_
* _winter is coming_

_False Slack is what people use to cope with "minor aggravations of modern
living" which are in actuality the tentacles of the Conspiracy digging out
one's brains through the belly button.
True Slack is what SubGeniuses would do in any ordinary situation, without prompting, were it not for the Conspiracy tentacles and its encouragement of
False Slack.

False Slack keeps one "sane" long enough to remain profitable; it always costs money to obtain, and fades away shortly after the money's gone.

True Slack keeps one INSANE, but in a way which makes good sense and from which only the slackful can benefit from; yet True Slack propagates and even increases as more people partake in it.

False Slack is like exchanging the fishhooks in your stomach with bent paper clips---you're left with the impression that that's an improvement on the situation, even if you are still in a universe of utter despair-ridden agony.

True Slack is like farting out those same fishhooks in a sudden blast of pyroflatulence, leaving one cleansed and joyous that the buggers are now and forever GONE.

I could go on. I won't. Not now, anyway.

P-Lil_

## Known Bugs

_{What do you mean?!?!?! IT WORKS ON MY COMPUTER!. }_

## Support and contact details

_{ABANDON HOPE ALL YE WHO ENTER.}_

## Technologies Used

_{THE POWER OF SLACK AND NICOLAS CAGE.}_

### License

*{Don't be donald trump}*

Copyright (c) 2015 **_{Acharjya and Durfey With liberty taken from The Church of the SubGeniuses}_**
# webpage
