This is a webpage for the very wealthy Scrooge McDuck's island retreat for the affluent.
