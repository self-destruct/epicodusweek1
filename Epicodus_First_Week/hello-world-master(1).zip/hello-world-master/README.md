place the .pairs file in the home directory. 
It is a template for pair programming, to be used in conjunction with $ git pair / $ git-pair-commit

Look for how to install the associated gem elsewhere.
